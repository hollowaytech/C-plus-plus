// Braedon Holloway
// Data Packet Reader
// Version 1.0 - Syntax Fixed

/* This program is designed to put a specific data packet through a cycle of conditions and statements
to see what the ending value will be. */
#include <iostream>
#include <string>
using namespace std;

int main()
{
	cout << "===DATA=PACKET=READER===" << endl << endl;
	cout << "Enter data packet name here: ";
	string n; // name
	cin >> n;
	cout << endl;

	cout << "Your data packet name is " << n << ". Is this correct? Enter [Y] if yes and [N] if no: ";
	string b1; // bool 1
	cin >> b1;
	cout << endl;

	if (b1 == "Y")
	{
		cout << "Your data packet name is " << n << "." << endl << endl;
		cout << "Enter data packet value here: ";
		int v; // value
		cin >> v;
		cout << endl;

		if (v < 0)
		{
			cout << "ERROR: CANNOT ENTER VALUE LESS THAN 0. RESET PROGRAM."; // error if value is negative
		}
		else
		{
			cout << "Your data packet value is " << v << ". Is this correct? Enter [Y] if yes and [N] if no: ";
			string b2; // bool 2
			cin >> b2;
			cout << endl;

			if (b2 == "Y")
			{
				cout << "===DATA=PACKET=SPECS===" << endl;
				cout << "|name: " << n << "|" << endl;
				cout << "|value: " << v << "|" << endl;
				cout << "=======================" << endl << endl;

				cout << "===CYCLE=PHASE===" << endl << endl;
				cout << "Enter amount of cycles desired here: ";
				int cds; // cycles desired
				cin >> cds;
				cout << endl;

				// c = current cycle
				for(int c = 1; c <= cds; c++)
				{
					if (v % 2 == 0)
					{
						v+=50;
					}
					else
					{
						v+=100;
					}
					if (v >= 1000)
					{
						v*=4;
					}
					else
					{
						v*=2;
					}
					int cl = cds - c; // cycles left
					cout << "================" << endl;
					cout << "cycle: " << c << endl;
					cout << "cycles left: " << cl << endl;
					cout << "value of " << n << ": " << v << endl;
				}
				cout << endl;
				cout << "===FINAL=CHART===" << endl;
				cout << "|name: " << n << "|" << endl;
				cout << "|final value: " << v << "|" << endl;
				cout << "|total cycles: " << cds << "|" << endl;
				cout << "=================";
			}
			else if (b2 == "N")
			{
				cout << "No worries, enter correct data packet value here: ";
				cin >> v;
				cout << endl;

				if (v < 0)
				{
					cout << "ERROR: CANNOT ENTER VALUE LESS THAN 0. RESET PROGRAM."; // error if value is negative
				}
				else
				{
					cout << "===DATA=PACKET=SPECS===" << endl;
					cout << "|name: " << n << "|" << endl;
					cout << "|value: " << v << "|" << endl;
					cout << "=======================" << endl << endl;

					cout << "===CYCLE=PHASE===" << endl << endl;
					cout << "Enter amount of cycles desired here: ";
					int cds; // cycles desired
					cin >> cds;
					cout << endl;

					// c = current cycle
					for(int c = 1; c <= cds; c++)
					{
						if (v % 2 == 0)
						{
							v+=50;
						}
						else
						{
							v+=100;
						}
						if (v >= 1000)
						{
							v*=4;
						}
						else
						{
							v*=2;
						}
						int cl = cds - c; // cycles left
						cout << "================" << endl;
						cout << "cycle: " << c << endl;
						cout << "cycles left: " << cl << endl;
						cout << "value of " << n << ": " << v << endl;
					}
					cout << endl;
					cout << "===FINAL=CHART===" << endl;
					cout << "|name: " << n << "|" << endl;
					cout << "|final value: " << v << "|" << endl;
					cout << "|total cycles: " << cds << "|" << endl;
					cout << "=================";
				}
			}
			else
			{
				cout << "ERROR: VALUE INVALID. RESET PROGRAM."; // Handles bad inputs for the first b2 branch
			}
		}
	}
	else if (b1 == "N")
	{
		cout << "No worries, enter correct data packet name here: ";
		cin >> n; // name corrected
		cout << endl;

		cout << "Your corrected data packet name is " << n << "." << endl << endl;
		cout << "Enter data packet value here: ";
		int v; // value
		cin >> v;
		cout << endl;

		if (v < 0)
		{
			cout << "ERROR: CANNOT ENTER VALUE LESS THAN 0. RESET PROGRAM."; // error if value is negative
		}
		else
		{
			cout << "Your data packet value is " << v << ". Is this correct? Enter [Y] if yes and [N] if no: ";
			string b2; // bool 2
			cin >> b2;
			cout << endl;

			if (b2 == "Y")
			{
				cout << "===DATA=PACKET=SPECS===" << endl;
				cout << "|name: " << n << "|" << endl;
				cout << "|value: " << v << "|" << endl;
				cout << "=======================" << endl << endl;

				cout << "===CYCLE=PHASE===" << endl << endl;
				cout << "Enter amount of cycles desired here: ";
				int cds; // cycles desired
				cin >> cds;
				cout << endl;

				// c = current cycle
				for(int c = 1; c <= cds; c++)
				{
					if (v % 2 == 0)
					{
						v+=50;
					}
					else
					{
						v+=100;
					}
					if (v >= 1000)
					{
						v*=4;
					}
					else
					{
						v*=2;
					}
					int cl = cds - c; // cycles left
					cout << "================" << endl;
					cout << "cycle: " << c << endl;
					cout << "cycles left: " << cl << endl;
					cout << "value of " << n << ": " << v << endl;
				}
				cout << endl;
				cout << "===FINAL=CHART===" << endl;
				cout << "|name: " << n << "|" << endl;
				cout << "|final value: " << v << "|" << endl;
				cout << "|total cycles: " << cds << "|" << endl;
				cout << "=================";
			}
			else if (b2 == "N")
			{
				cout << "No worries, enter correct data packet value here: ";
				cin >> v;
				cout << endl;

				if (v < 0)
				{
					cout << "ERROR: CANNOT ENTER VALUE LESS THAN 0. RESET PROGRAM."; // error if value is negative
				}
				else
				{
					cout << "===DATA=PACKET=SPECS===" << endl;
					cout << "|name: " << n << "|" << endl;
					cout << "|value: " << v << "|" << endl;
					cout << "=======================" << endl << endl;

					cout << "===CYCLE=PHASE===" << endl << endl;
					cout << "Enter amount of cycles desired here: ";
					int cds; // cycles desired
					cin >> cds;
					cout << endl;

					// c = current cycle
					for(int c = 1; c <= cds; c++)
					{
						if (v % 2 == 0)
						{
							v+=50;
						}
						else
						{
							v+=100;
						}
						if (v >= 1000)
						{
							v*=4;
						}
						else
						{
							v*=2;
						}
						int cl = cds - c; // cycles left
						cout << "================" << endl;
						cout << "cycle: " << c << endl;
						cout << "cycles left: " << cl << endl;
						cout << "value of " << n << ": " << v << endl;
					}
					cout << endl;
					cout << "===FINAL=CHART===" << endl;
					cout << "|name: " << n << "|" << endl;
					cout << "|final value: " << v << "|" << endl;
					cout << "|total cycles: " << cds << "|" << endl;
					cout << "=================";
				}
			}
			else
			{
				cout << "ERROR: VALUE INVALID. RESET PROGRAM."; // Handles bad inputs for the second b2 branch
			}
		}
	}
	else
	{
		cout << "ERROR: VALUE INVALID. RESET PROGRAM."; // value error for b1
	}

	return 0;
}
