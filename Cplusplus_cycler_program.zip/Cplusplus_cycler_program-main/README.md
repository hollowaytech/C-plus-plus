# Cplusplus_cycler_program
Contains:
# For loop
(Loop for counter)
# if - else if - else statements
(Statements to execute and monitor different actions and conditions)
# multiple alternatives and parameters
(Multiple paths in program)
# clean syntax
(Easily readable code)
